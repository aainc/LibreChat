/**
 * PoC verification: `promptCacheTTL: '1h'` configured on AnthropicClientOptions
 * propagates into the actual Anthropic request payload's `cache_control`
 * markers — without requiring a real API key.
 *
 * Request assembly is verified via `_convertMessagesToAnthropicPayload`,
 * the same function `CustomAnthropic` uses to build the request body
 * (see src/llm/anthropic/index.ts `_streamResponseChunks`).
 */
import { HumanMessage, AIMessage } from '@langchain/core/messages';
import { AgentContext } from '../AgentContext';
import { Providers } from '@/common';
import { addCacheControl } from '@/messages/cache';
import {
  partitionAndMarkAnthropicToolCache,
  makeIsDeferred,
} from '@/messages/anthropicToolCache';
import { _convertMessagesToAnthropicPayload } from '@/llm/anthropic/utils/message_inputs';
import type * as t from '@/types';

type CacheControl = { type: string; ttl?: string };
type TextBlock = { type: 'text'; text: string; cache_control?: CacheControl };

const createAnthropicContext = (
  clientOptions: t.AnthropicClientOptions
): AgentContext =>
  AgentContext.fromConfig({
    agentId: 'ttl-poc-agent',
    provider: Providers.ANTHROPIC,
    instructions: 'Stable instructions',
    clientOptions,
  });

describe('PoC: promptCacheTTL propagation into Anthropic request payload', () => {
  it('stamps ttl:1h on the system block cache_control in the request payload', async () => {
    const ctx = createAnthropicContext({
      model: 'claude-sonnet-4-6',
      promptCache: true,
      promptCacheTTL: '1h',
    });

    const finalMessages = await ctx.systemRunnable!.invoke([
      new HumanMessage('Hello'),
      new AIMessage('Hi!'),
      new HumanMessage('Second turn'),
    ]);

    // Same conversion CustomAnthropic applies right before the HTTP request
    const payload = _convertMessagesToAnthropicPayload(finalMessages);

    const systemBlocks = payload.system as unknown as TextBlock[];
    expect(Array.isArray(systemBlocks)).toBe(true);
    expect(systemBlocks[0].cache_control).toEqual({
      type: 'ephemeral',
      ttl: '1h',
    });

    // Conversation cache markers (last 2 user messages) also carry the TTL
    const markers: CacheControl[] = [];
    for (const message of payload.messages) {
      if (!Array.isArray(message.content)) continue;
      for (const block of message.content) {
        const cc = (block as TextBlock).cache_control;
        if (cc != null) markers.push(cc);
      }
    }
    expect(markers.length).toBeGreaterThan(0);
    for (const marker of markers) {
      expect(marker).toEqual({ type: 'ephemeral', ttl: '1h' });
    }
  });

  it('keeps default ephemeral (no ttl) when promptCacheTTL is not set', async () => {
    const ctx = createAnthropicContext({
      model: 'claude-sonnet-4-6',
      promptCache: true,
    });

    const finalMessages = await ctx.systemRunnable!.invoke([
      new HumanMessage('Hello'),
      new AIMessage('Hi!'),
      new HumanMessage('Second turn'),
    ]);
    const payload = _convertMessagesToAnthropicPayload(finalMessages);

    const systemBlocks = payload.system as unknown as TextBlock[];
    expect(systemBlocks[0].cache_control).toEqual({ type: 'ephemeral' });
    expect(
      (systemBlocks[0].cache_control as CacheControl).ttl
    ).toBeUndefined();
  });

  it('stamps ttl:1h via addCacheControl for raw message arrays', () => {
    const messages = [
      new HumanMessage('First'),
      new AIMessage('Reply'),
      new HumanMessage('Second'),
    ];
    const result = addCacheControl(messages, '1h');
    const last = result[result.length - 1];
    const blocks = last.content as TextBlock[];
    expect(blocks[blocks.length - 1].cache_control).toEqual({
      type: 'ephemeral',
      ttl: '1h',
    });
  });

  it('stamps ttl:1h on the last static tool definition', () => {
    const tools = [
      { name: 'tool_a', description: 'a' },
      { name: 'tool_b', description: 'b' },
      { name: 'deferred_c', description: 'c' },
    ] as unknown as t.GraphTools;

    const marked = partitionAndMarkAnthropicToolCache(
      tools,
      makeIsDeferred([{ name: 'deferred_c', defer_loading: true }]),
      '1h'
    );

    const staticLast = (marked as Array<Record<string, unknown>>)[1] as {
      extras?: { cache_control?: CacheControl };
    };
    expect(staticLast.extras?.cache_control).toEqual({
      type: 'ephemeral',
      ttl: '1h',
    });
  });

  it('stamps ttl on summary human message when summary is present', async () => {
    const ctx = createAnthropicContext({
      model: 'claude-sonnet-4-6',
      promptCache: true,
      promptCacheTTL: '1h',
    });
    ctx.setSummary('A summary of prior conversation.', 3);

    const finalMessages = await ctx.systemRunnable!.invoke([
      new HumanMessage('Hello'),
      new AIMessage('Hi!'),
      new HumanMessage('Second turn'),
    ]);
    const payload = _convertMessagesToAnthropicPayload(finalMessages);

    const ttlMarkers: CacheControl[] = [];
    for (const message of payload.messages) {
      if (!Array.isArray(message.content)) continue;
      for (const block of message.content) {
        const cc = (block as TextBlock).cache_control;
        if (cc != null) ttlMarkers.push(cc);
      }
    }
    expect(ttlMarkers.length).toBeGreaterThan(0);
    for (const marker of ttlMarkers) {
      expect(marker.ttl).toBe('1h');
    }
  });
});
